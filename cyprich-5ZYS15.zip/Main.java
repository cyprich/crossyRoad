/**
 * Spusta cely program
 * 
 * @author Peter Cyprich
 * @version 1.0 (2024-01-06)
 */
public class Main {
    /**
     * Spusta cely program
     */
    public static void main(String[] args) {
        Hra hra = new Hra();
    }
}
